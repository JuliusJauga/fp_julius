{-# LANGUAGE InstanceSigs #-}
module Lib3
    ( stateTransition,
    StorageOp (..),
    storageOpLoop,
    parseCommand,
    parseStatements,
    marshallState,
    renderStatements
    ) where

import Control.Concurrent ( Chan , readChan, writeChan, newChan )
import Control.Concurrent.STM(TVar, atomically, readTVarIO, readTVar, writeTVar)
import Data.List (isPrefixOf, isSuffixOf, notElem, (\\), intercalate, find, delete, partition)
import qualified Lib2
import Data.Char (isSpace)
import Debug.Trace
import Data.Either (partitionEithers)

-- instance Show Lib2.Query where
--     show = genQuery 

data StorageOp = Save String (Chan ()) | Load (Chan String)
-- | This function is started from main
-- in a dedicated thread. It must be used to control
-- file access in a synchronized manner: read requests
-- from chan, do the IO operations needed and respond
-- to a channel provided in a request.
-- Modify as needed.
storageOpLoop :: Chan StorageOp -> IO ()
storageOpLoop chan = loop
  where
    loop = do
      op <- readChan chan -- reading the operation
      case op of
        Save info saveChannel -> do -- saving the info about status into a file
          writeFile "info.txt" info
          writeChan saveChannel ()
        Load loadChannel -> do
          info <- readFile "info.txt"
          writeChan loadChannel info
      loop

data Statements = Batch [Lib2.Query] |
               Single Lib2.Query
               deriving (Show, Eq)

data Command = StatementCommand Statements |
               LoadCommand |
               SaveCommand
               deriving (Show, Eq)

-- | Helper function
trim :: String -> String
trim = f . f
    where f = reverse . dropWhile (== ' ')


-- | Parses user's input.
parseCommand :: String -> Either String (Command, String)
parseCommand input
    | "load" `isPrefixOf` input = Right (LoadCommand, drop 4 input)
    | "save" `isPrefixOf` input = Right (SaveCommand, drop 4 input)
    | "BEGIN" `isPrefixOf` input = case parseStatements input of
        Left err -> Left err
        Right (stmts, rest) -> Right (StatementCommand stmts, rest)
    | otherwise = case Lib2.parseQuery (trim input) of
        Left err -> Left err
        Right (query, rest) -> Right (StatementCommand (Single query), rest)
        
-- | Parses Statement.
-- Must be used in parseCommand.
-- Reuse Lib2 as much as you can.
-- You can change Lib2.parseQuery signature if needed.
-- | Parses Statement.
-- Must be used in parseCommand.
-- Reuse Lib2 as much as you can.
-- You can change Lib2.parseQuery signature if needed.
parseStatements :: String -> Either String (Statements, String)
parseStatements input =
  let inputTrim = trim input
  in if "BEGIN" `isPrefixOf` inputTrim
    then
      if "END" `isSuffixOf` inputTrim
        then
          let body = trim $ drop 5 $ take (length inputTrim - 3) inputTrim
          in if null body
            then Right (Batch [], "") -- empty batch
            else
              let queries = map (Lib2.parseQuery . trim) (filter (not . null) $ splitOn ';' body)
                  (errors, parsedQueries) = partitionEithers queries
              in if null errors
                then Right (Batch (map fst parsedQueries), "")
                else Left $ "Error parsing queries: " ++ unlines errors
        else Left "Batch must end with 'END'"
    else Left "Batch must start with 'BEGIN'"


splitOn :: Char -> String -> [String]
splitOn _ [] = [""]
splitOn c (x:xs)
  | c == x = "" : rest
  | otherwise = (x : head rest) : tail rest
  where rest = splitOn c xs

-- | Converts program's state into Statements
-- (probably a batch, but might be a single query)
marshallState :: Lib2.State -> Statements
marshallState finalState =
  let
    emptyState = Lib2.initialState

    -- Find added and removed route trees
    findAddedRouteTrees :: [(Lib2.Name, [Lib2.RouteTree])] -> [(Lib2.Name, [Lib2.RouteTree])] -> [(Lib2.Name, [Lib2.RouteTree])]
    findAddedRouteTrees initial final = filter (\(name, trees) -> notElem (name, trees) initial) final

    findRemovedRouteTrees :: [(Lib2.Name, [Lib2.RouteTree])] -> [(Lib2.Name, [Lib2.RouteTree])] -> [(Lib2.Name, [Lib2.RouteTree])]
    findRemovedRouteTrees initial final = filter (\(name, trees) -> notElem (name, trees) final) initial

    -- Generate queries for added and removed route trees
    addRouteTreeQueries :: [(Lib2.Name, [Lib2.RouteTree])] -> [Lib2.Query]
    addRouteTreeQueries = concatMap (\(name, trees) -> map (\tree -> Lib2.ListAdd name (convertRouteTreeToRoute tree)) trees)

    removeRouteTreeQueries :: [(Lib2.Name, [Lib2.RouteTree])] -> [Lib2.Query]
    removeRouteTreeQueries = map (\(name, _) -> Lib2.ListRemove name)

    -- Convert RouteTree to Route
    convertRouteTreeToRoute :: Lib2.RouteTree -> Lib2.Route
    convertRouteTreeToRoute Lib2.EmptyTree = error "Cannot convert EmptyTree to Route"
    convertRouteTreeToRoute (Lib2.Node (Lib2.NodeRoute routeId stops) nestedTrees) =
      Lib2.Route routeId stops (map convertRouteTreeToRoute nestedTrees)

    -- Find the actual queries
    addedRouteTrees = findAddedRouteTrees (Lib2.routeTreeLists emptyState) (Lib2.routeTreeLists finalState)
    removedRouteTrees = findRemovedRouteTrees (Lib2.routeTreeLists emptyState) (Lib2.routeTreeLists finalState)

    addRouteTreeQueries' = addRouteTreeQueries addedRouteTrees
    removeRouteTreeQueries' = removeRouteTreeQueries removedRouteTrees

    combinedQueries = addRouteTreeQueries' ++ removeRouteTreeQueries'

    -- Filter out queries that cancel each other out
    isCancelled :: Lib2.Query -> Lib2.Query -> Bool
    isCancelled (Lib2.ListAdd name1 _) (Lib2.ListRemove name2) = name1 == name2
    isCancelled (Lib2.ListRemove name1) (Lib2.ListAdd name2 _) = name1 == name2
    isCancelled _ _ = False

    filterCancelled :: [Lib2.Query] -> [Lib2.Query]
    filterCancelled [] = []
    filterCancelled (q:qs) =
      case find (isCancelled q) qs of 
        Just matchingQuery -> filterCancelled (delete matchingQuery qs)
        Nothing -> q : filterCancelled qs
      
    finalQueries = filterCancelled combinedQueries

  in
    case finalQueries of
      [query] -> Single query
      queries -> Batch queries

-- | Renders Statements into a String which
-- can be parsed back into Statements by parseStatements
-- function. The String returned by this function must be used
-- as persist program's state in a file. 
-- Must have a property test
-- for all s: parseStatements (renderStatements s) == Right(s, "")
renderStatements :: Statements -> String
renderStatements (Single query) =
  "BEGIN \n" ++ genQuery query ++ "\n END"
renderStatements (Batch queries) =
  "BEGIN \n " ++ unlines (map genQuery queries) ++ "\n END"


genQuery :: Lib2.Query -> String
genQuery (Lib2.ListCreate name) =
    "list-create " ++ show name
genQuery (Lib2.ListAdd name route) =
    "list-add " ++ show name ++ " " ++ genRoute route
genQuery (Lib2.ListGet name) =
    "list-get " ++ show name
genQuery (Lib2.ListRemove name) =
    "list-remove " ++ show name
genQuery (Lib2.RouteCreate name) =
    "route-create " ++ show name
genQuery (Lib2.RouteGet name) =
    "route-get " ++ show name
genQuery (Lib2.RouteAddRoute parentRoute childRoute) =
    "route-add-route " ++ genRoute parentRoute ++ " " ++ genRoute childRoute
genQuery (Lib2.RouteAddStop name stop) =
    "route-add-stop " ++ show name ++ " " ++ genStop stop
genQuery (Lib2.RouteRemoveStop name stop) =
    "route-remove-stop " ++ show name ++ " " ++ genStop stop
genQuery (Lib2.RouteRemove name) =
    "route-remove " ++ show name
genQuery (Lib2.StopCreate name) =
    "stop-create " ++ show name
genQuery (Lib2.StopDelete name) =
    "stop-delete " ++ show name
genQuery (Lib2.RoutesFromStop stop) =
    "routes-from-stop " ++ genStop stop

genRoute :: Lib2.Route -> String
genRoute (Lib2.Route routeId stops nestedRoutes) =
        "<" ++ show routeId ++ "{" ++ genStops stops ++ " " ++ genNestedRoutes nestedRoutes ++ "}>"

genStops :: [Lib2.Stop] -> String
genStops stops = intercalate " " (map genStop stops)

genStop :: Lib2.Stop -> String
genStop (Lib2.Stop stopId) = "(" ++ show stopId ++ ")"

genNestedRoutes :: [Lib2.Route] -> String
genNestedRoutes nestedRoutes = intercalate " " (map genRoute nestedRoutes)


-- | Updates a state according to a command.
-- Performs file IO via ioChan if needed.
-- This allows your program to share the state
-- between repl iterations, save the state to a file,
-- load the state from the file so the state is preserved
-- between program restarts.
-- Keep IO as small as possible.
-- State update must be executed atomically (STM).
-- Right contains an optional message to print, updated state
-- is stored in transactinal variable
stateTransition :: TVar Lib2.State -> Command -> Chan StorageOp ->
            IO (Either String (Maybe String, String))
stateTransition stateVar command ioChan = case command of
  LoadCommand -> do
    loadChan <- newChan
    writeChan ioChan (Load loadChan)
    info <- readChan loadChan
    case parseStatements info of
      Right (statements, _) -> atomically $ do
        initialState <- readTVar stateVar
        case statements of
          Batch queries -> do
            let applyQueries = foldl (\stateRes query -> case stateRes of
                  Right state -> case Lib2.stateTransition state query of
                    Right newState -> Right newState
                    Left err -> Left err
                  Left err -> Left err) (Right initialState) queries
            case applyQueries of
              Right newState -> do
                writeTVar stateVar newState
                return $ Right (Just "Loading was successful.", show newState)
              Left err -> return $ Left ("Error applying queries: " ++ err)
          Single query -> do
            case Lib2.stateTransition initialState query of
              Right newState -> do
                writeTVar stateVar newState
                return $ Right (Just "Loading was successful.", show query)
              Left err -> return $ Left ("Error applying query: " ++ err)
      Left err -> return $ Left ("Error parsing statements: " ++ err)

  SaveCommand -> do
    currentState <- readTVarIO stateVar
    let state = renderStatements (marshallState currentState)
    saveChan <- newChan
    writeChan ioChan (Save state saveChan)
    _ <- readChan saveChan
    return $ Right (Just "State saving was successful.", show currentState)

  StatementCommand statements -> atomically $ do
      currentState <- readTVar stateVar
      case statements of
        Batch queries -> do
          -- Apply the queries
          let applyQueries = foldl (\stateRes query -> case stateRes of
                Right state -> case Lib2.stateTransition state query of
                  Right newState -> Right newState
                  Left err -> Left err
                Left err -> Left err) (Right currentState) queries

          case applyQueries of
            Right newState -> do
              writeTVar stateVar newState
              return $ Right (Just "Statements executed successfully.", show newState)
            Left err -> return $ Left ("Error executing statements: " ++ err)
        Single query -> do
          case Lib2.stateTransition currentState query of
            Right newState -> do
              writeTVar stateVar newState
              return $ Right (Just "Statement executed successfully.", show newState)
            Left err -> return $ Left ("Error executing statement: " ++ err)
